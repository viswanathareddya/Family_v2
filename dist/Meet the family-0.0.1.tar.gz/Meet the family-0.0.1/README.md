Solving the problem of Family provided by Geektrust.

Creating solution for adding a child via only mother who is existing in the family.

Getting the relatives names of corresponding input of relationship type for a given member of family

How to get code working:

pip install -r requirements.txt
python -m geektrust <absolute_path_to_input_file>


How to run tests:

python -m unittest discover -s "tests" -p "test_*.py"